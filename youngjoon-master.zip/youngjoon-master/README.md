# algorithm study - youngjoon
알고리즘 스터디 김영준

| Weeks | Lang | Site | Title | Source Shortcut | Result Shortcut |
| :--------: | :--------: | :--------: | -------- | :--------: | :--------: |
| 25-1 | JAVA | hackerrank | [Repeated String](https://www.hackerrank.com/challenges/repeated-string/problem) |  [바로가기](https://github.com/0Joon/youngjoon/blob/master/25/RepeatedString.java) |  [결과](https://github.com/0Joon/youngjoon/issues/1) |
| 25-2 | JAVA | hackerrank | [Insertion Sort - Part 1](https://www.hackerrank.com/challenges/insertionsort1/problem) |  [바로가기](https://github.com/0Joon/youngjoon/blob/master/25/InsertionSort1.java) |  [결과](https://github.com/0Joon/youngjoon/issues/2) |
